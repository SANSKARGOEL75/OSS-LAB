# Python

<h2>1 - Notification</h2>
<p>We learn how to send <b>Notification</b> with <b>Python</b></p>
<br>
<h2>2 - Battery</h2>
<p>We learn how to get <b>Battery Percentage</b> with <b>Python</b></p>
