# Python Notification

Link of this repository:
https://virgool.io/@BlackIQ/python-notifier-jpd4h9ow9c4o

Link in Telegram Channel:
https://t.me/Amir_Net/79

Amirhossein :)
