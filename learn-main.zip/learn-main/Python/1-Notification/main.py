from notifypy import Notify

notification = Notify()

notification.title = "Notification Title"
notification.message = "Notification Message"

notification.send()
