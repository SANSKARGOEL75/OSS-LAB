# Python Battery Percentage

Link of this repository:
https://virgool.io/@BlackIQ/battery-percentage-paedt4ngepvx

Link in Telegram Channel:
https://t.me/Amir_Net/80

Amirhossein :)
