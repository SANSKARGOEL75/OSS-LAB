# Init a List
array = [10, 12, 14, 16, 18]

# Get len
leng = len(array)

# Loop
for i in range(leng):
	# Print
	print(f"Place {i} is : {array[i]}")
