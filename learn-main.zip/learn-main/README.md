# learn

I'll teach useful things in telegram channel and put codes here.

<h3>Python</h3>
<p>1 - Notification</p>
<p>2 - Battery</p>

<hr>

<h3>C</h3>
<p>3 - Len</p>
